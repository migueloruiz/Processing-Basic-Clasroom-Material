import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import saito.objloader.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ObJLoader_Transform_SAITO extends PApplet {


OBJModel model;
OBJModel tmpmodel;
float rotX;
float rotY;
public void setup()
{
  size(600, 600, P3D);
  frameRate(30);
  model = new OBJModel(this);
  tmpmodel = new OBJModel(this);
  model.enableDebug();
  model.load("dma.obj");
  tmpmodel.load("dma.obj");
  stroke(255);
}
public void draw()
{
  background(128);
  lights();
  pushMatrix();
  translate(width/2, height/2, 0);
  rotateX(rotY);
  rotateY(rotX);
  scale(20.0f);

  // renders the temporary model
  tmpmodel.draw();

  popMatrix();

  animation();
}
// transformation parameter
float k = 0.0f;
// transforms the orignal model shape and stores transformed shape 
// into temporary model storage
public void animation(){

  for(int i = 0; i < model.getVertexCount(); i++){
    PVector orgv = model.getVertex(i);
    PVector tmpv = new PVector();
    tmpv.x = orgv.x * (abs(sin(k+i*0.04f)) * 0.3f + 1.0f);
    tmpv.y = orgv.y * (abs(cos(k+i*0.04f)) * 0.3f + 1.0f);
    tmpv.z = orgv.z * (abs(cos(k/5.f)) * 0.3f + 1.0f);
    tmpmodel.setVertex(i, tmpv);
  }
  k+=0.1f;
}

public void mouseDragged()
{
  rotX += (mouseX - pmouseX) * 0.01f;
  rotY -= (mouseY - pmouseY) * 0.01f;
}


  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ObJLoader_Transform_SAITO" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
