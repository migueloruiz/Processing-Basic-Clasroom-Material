import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import saito.objloader.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class OBJLoader_OOP_integration extends PApplet {



SimpleClass s;

public void setup()
{
  
  size(400, 400, P3D);
  
  s = new SimpleClass("map_ground_path_s.obj", this);
}


public void draw()
{
  background(128);
  lights();
  
  translate(width/2, height/2, 0);

  rotateY(radians(frameCount)/2);
  
  s.draw();

}
class SimpleClass
{

  OBJModel model; 

  SimpleClass(String s, PApplet parent)
  {
    model = new OBJModel(parent, s, OBJModel.ABSOLUTE, QUADS);

    // this is done becaue the model was made in meters 1 = 1m
    // where processing is 1 = 1pixel
    model.scale(100);
    model.translateToCenter();
  }

  public void draw()
  {
      noStroke();
    model.draw(); 
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "OBJLoader_OOP_integration" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
